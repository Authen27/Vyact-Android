# Vyact · Google Play listing

Release 9 · version 0.5 · English (default)

## App title (30 max)
Vyact — Family Finance OS

## Short description (80 max)
Shared budgets, bills, splits and an AI assistant for your whole household.

## Full description (4000 max)
Vyact brings your household's spending, budgets, bills, debts and net worth into one shared picture. Everyone works from the same numbers, so you know where the money went, what's coming next and what you can afford.

ASK PIP
Ask about your money in plain words. "Can we afford a weekend away?" "How much is left for groceries?" Pip answers from your own budgets and balances, with the figures, and tells you plainly when something is tight. When you tell Pip about a spend, it shows what it understood so you can check it before saving.

LOG A SPEND FROM WHATSAPP
Link your number and message Pip like a friend: "auto 450" or "groceries 2340". The entry lands in the right account and budget, and you can undo it from the chat.

ONE PICTURE FOR THE WHOLE HOUSEHOLD
Invite your partner or family. Choose who can edit and who can only view. Personal spending can stay out of the shared totals.

BUDGETS THAT WARN YOU EARLY
Set monthly or annual budgets by category. Vyact tells you when a category reaches 80%, before it runs out.

SPLIT A BILL WITH ANYONE
Share a bill with people inside or outside your household. Only your share counts toward your spending. See who owes what and settle up.

A CLEAR PLAN TO PAY OFF DEBT
Loans and cards side by side, an avalanche or snowball payoff order, the interest inside every payment, and what an extra payment does to the date you're clear.

BILLS THAT DON'T SLIP
Recurring bills and income in a calendar. Approve what's due, skip it once, or let it post by itself.

NET WORTH AND REPORTS
Net worth across cash, bank accounts, cards, loans and investments, recorded month by month. Cash-flow and category reports for any date range.

ALSO
• Light and dark themes
• Works in your household's own currency
• Works offline; changes sync when you're back
• Undo for quick actions

Pip is AI-based and can make mistakes. Check entries before you save them, and use the thumbs up or down on any answer to tell us how it did.

WhatsApp is a trademark of WhatsApp LLC. Vyact is not affiliated with or endorsed by WhatsApp.

## What's new · release 9 (0.5) (500 max)
• A refreshed look, with a new light theme
• Pip shows what it understood before you save an entry
• Undo for quick actions; clearer confirmations for the rest
• Notifications put what needs you first
• An offline banner shows changes waiting to sync
• A setup checklist for new households

## Assets in this folder
| File | Size | Play Console slot |
|---|---|---|
| phone/01–08 | 1080 × 1920 | Phone screenshots (upload in this order; 01 is the lead) |
| tablet-7in/01–04 | 1920 × 1200 | 7-inch tablet screenshots |
| tablet-10in/01–04 | 2560 × 1600 | 10-inch tablet screenshots |
| feature-graphic-1024x500.png | 1024 × 500 | Feature graphic |
| app-icon-512.png | 512 × 512 | App icon (full square, no rounded corners; Play applies the mask) |

## Before you publish
- **What's new:** check every line ships in this build; remove any that don't.
- **WhatsApp:** the screenshots name WhatsApp but use a neutral chat design with no WhatsApp logo or colours. Keep the trademark line in the full description. Google may still question third-party brand names in screenshots; if a review flags it, change the caption to "Log a spend by message".
- **AI disclosure:** Play's AI-generated content policy expects a way to report responses. Pip's thumbs up/down covers this; mention it in the Data safety and content declarations if asked.
- **Sample data:** names (Maya, Sam, Alex, Jordan) and amounts are illustrative. Currencies vary by screenshot (₹, $, €, £) to show that each household uses its own currency.
- **Source:** `playstore/Vyact Play Store.html` in the project re-renders every asset.
